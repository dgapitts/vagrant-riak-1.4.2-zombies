from riak_pb2 import *
from riak_kv_pb2 import *
from riak_search_pb2 import *
